/* Snacki v1.1.0 */
(function(){'use strict';

/* ---------- Configuration (à valider avec l'équipe) ---------- */
const CONFIG = {
  whatsapp: '22237939409',          // +222 37 93 94 09
  call: '41445574',
  unit: {fr:'MRU', ar:'MRU'},        // ouguiya (MRU) — décision validée
  zones: [
    {id:'ndb', fr:'Nouadhibou (ville)', ar:'انواذيبو (المدينة)'},
    {id:'cansado', fr:'Cansado', ar:'كانصادو'},
    {id:'autre', fr:'Autre quartier', ar:'حي آخر'}
  ],
  payments: [
    {id:'cash', fr:'Espèces', ar:'نقدًا', mobile:false},
    {id:'bankily', fr:'Bankily', ar:'بنكيلي', mobile:true},
    {id:'sedad', fr:'Sedad', ar:'السداد', mobile:true},
    {id:'bimbank', fr:'Bimbank', ar:'بيم بنك', mobile:true},
    {id:'bamis', fr:'Bamis Digital', ar:'باميس ديجيتال', mobile:true}
  ]
};

const PRODUCTS = [
  {id:'salade', cat:'delices', price:100, badge:'top',
   fr:'Salade de fruits', ar:'صلاد فروي',
   dfr:'Pomme, poire, raisin, dattes, banane, crème d’avocat', dar:'تفاح، إجاص، عنب، تمر، موز مع كريمة الأفوكا'},
  {id:'crepe', cat:'delices', price:120, badge:'pop',
   fr:'Crêpe', ar:'اكريب',
   dfr:'Chocolat et banane', dar:'شوكولاتة وموز'},
  {id:'avocat', cat:'jus', price:100, badge:'pop',
   fr:'Jus avocat', ar:'عصير أفوكا',
   dfr:'Avocat mixé au lait', dar:'أفوكا بالحليب'},
  {id:'fraise', cat:'jus', price:100,
   fr:'Jus fraise', ar:'عصير الفراولة',
   dfr:'Fraises mixées au lait', dar:'فراولة بالحليب'},
  {id:'mangue', cat:'jus', price:100,
   fr:'Jus mangue', ar:'عصير مانكو',
   dfr:'Mangue bien fraîche', dar:'مانكو بارد'},
  {id:'orange', cat:'jus', price:100,
   fr:'Jus orange', ar:'عصير البرتقال',
   dfr:'Oranges pressées', dar:'برتقال معصور'},
  {id:'cocktail', cat:'jus', price:100,
   fr:'Jus cocktail', ar:'عصير كوكتيل',
   dfr:'Mélange de fruits', dar:'خليط فواكه'},
  {id:'banane-fraise', cat:'jus', price:100,
   fr:'Jus banane-fraise', ar:'عصير بنانة والفراولة',
   dfr:'Banane et fraise', dar:'موز وفراولة'},
  {id:'mojito', cat:'jus', price:100,
   fr:'Mojito', ar:'موخيتو',
   dfr:'Menthe et citron vert, sans alcool', dar:'نعناع وليمون، بدون كحول'}
];
/* ---------- Illustrations produits (SVG généré, aucune image externe) ---------- */
const ART = (function(){
  let uid = 0;
  const f = n => Math.round(n*10)/10;
  function rng(seed){ let s = seed; return () => (s = (s*16807) % 2147483647) / 2147483647; }

  /* Garnitures */
  const G = {
    strawberry(x,y,s,r){
      return `<g transform="translate(${x} ${y}) rotate(${r||0}) scale(${s})">
        <path d="M0 -11C10 -13 15 -3 9 8C6 13 1 17 0 17C-1 17 -6 13 -9 8C-15 -3 -10 -13 0 -11Z" fill="#E3303E"/>
        <path d="M-6 -6C-9 0 -7 7 -3 12" stroke="#F4717B" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".7"/>
        <g fill="#FFE39A">${[[-4,-4],[3,-5],[6,1],[-1,1],[-6,3],[3,7],[-2,9],[7,-2]].map(([a,b])=>`<ellipse cx="${a}" cy="${b}" rx=".9" ry="1.3"/>`).join('')}</g>
        <path d="M-9 -11L-3 -9L0 -16L3 -9L9 -11L4 -6L0 -8L-4 -6Z" fill="#3B8C2A"/></g>`;
    },
    avocado(x,y,s,r){
      return `<g transform="translate(${x} ${y}) rotate(${r||0}) scale(${s})">
        <path d="M0 -24C10 -24 13 -12 16 0C20 14 12 24 0 24C-12 24 -20 14 -16 0C-13 -12 -10 -24 0 -24Z" fill="#3D6A1E"/>
        <path d="M0 -21C8 -21 10 -11 13 0C16 12 10 21 0 21C-10 21 -16 12 -13 0C-10 -11 -8 -21 0 -21Z" fill="#CFE58A"/>
        <path d="M0 -17C6 -17 8 -9 10 0C13 10 8 18 0 18C-8 18 -13 10 -10 0C-8 -9 -6 -17 0 -17Z" fill="#E6F2A8"/>
        <circle cx="0" cy="6" r="8.5" fill="#8B5A2B"/><circle cx="-2.6" cy="3.4" r="2.6" fill="#B07A43"/></g>`;
    },
    citrus(x,y,rad,c){ // tranche : c = {rind, pith, flesh}
      const seg = Array.from({length:8},(_,i)=>{const a=i*Math.PI/4; return `<line x1="0" y1="0" x2="${f(Math.cos(a)*(rad-4))}" y2="${f(Math.sin(a)*(rad-4))}"/>`;}).join('');
      return `<g transform="translate(${x} ${y})"><circle r="${rad}" fill="${c.rind}"/><circle r="${rad-2}" fill="${c.pith}"/><circle r="${rad-3.5}" fill="${c.flesh}"/>
        <g stroke="${c.pith}" stroke-width="1.3">${seg}</g><circle r="2" fill="${c.pith}"/></g>`;
    },
    orange(x,y,s){
      return `<g transform="translate(${x} ${y}) scale(${s})"><circle r="17" fill="#F7901E"/><circle cx="-5" cy="-6" r="5" fill="#FFB65C" opacity=".8"/>
        <path d="M2 -16C6 -24 14 -24 17 -20C12 -18 7 -16 2 -16Z" fill="#3B8C2A"/><circle cx="1" cy="-16" r="1.8" fill="#6B4B1F"/></g>`;
    },
    mango(x,y,s,r){
      let grid=''; for(let i=-24;i<=24;i+=7){ grid += `<line x1="${i}" y1="-30" x2="${i}" y2="30"/><line x1="-30" y1="${i}" x2="30" y2="${i}"/>`; }
      const id='mg'+(++uid);
      return `<g transform="translate(${x} ${y}) rotate(${r||0}) scale(${s})">
        <defs><clipPath id="${id}"><path d="M-20 0C-20 -14 -8 -20 3 -19C15 -18 21 -8 20 3C19 15 8 20 -4 19C-14 18 -20 10 -20 0Z"/></clipPath></defs>
        <path d="M-22 1C-22 -15 -9 -22 3 -21C17 -20 23 -9 22 3C21 17 9 22 -4 21C-16 20 -22 11 -22 1Z" fill="#E8961B"/>
        <g clip-path="url(#${id})"><rect x="-30" y="-30" width="60" height="60" fill="#FFB52E"/><g stroke="#E58E10" stroke-width="1.6" transform="rotate(45)">${grid}</g></g></g>`;
    },
    cube(x,y,s,r,c){ return `<rect x="${f(x-5*s)}" y="${f(y-5*s)}" width="${f(10*s)}" height="${f(10*s)}" rx="${f(2.4*s)}" fill="${c}" transform="rotate(${r} ${x} ${y})"/>`; },
    banana(x,y,s,r){
      return `<g transform="translate(${x} ${y}) rotate(${r||0}) scale(${s})">
        <path d="M-24 -2C-12 14 14 14 25 -5C24 -1 20 3 15 6C3 12 -12 10 -24 -2Z" fill="#E7B400"/>
        <path d="M-24 -2C-12 10 12 10 25 -5C16 2 -8 4 -24 -2Z" fill="#FFD84A"/>
        <path d="M25 -5L28 -8" stroke="#6B4B1F" stroke-width="2.4" stroke-linecap="round"/><circle cx="-24" cy="-2" r="1.8" fill="#6B4B1F"/></g>`;
    },
    bananaSlice(x,y,s){ return `<g transform="translate(${x} ${y}) scale(${s})"><circle r="6.5" fill="#FFF3B8" stroke="#EBCB55" stroke-width="1.2"/><g fill="#C9A646"><circle cx="0" cy="-1.8" r=".8"/><circle cx="1.7" cy="1" r=".8"/><circle cx="-1.7" cy="1" r=".8"/></g></g>`; },
    kiwi(x,y,s){
      const seeds = Array.from({length:12},(_,i)=>{const a=i*Math.PI/6; return `<ellipse cx="${f(Math.cos(a)*7)}" cy="${f(Math.sin(a)*7)}" rx=".9" ry="1.6" transform="rotate(${i*30+90} ${f(Math.cos(a)*7)} ${f(Math.sin(a)*7)})"/>`;}).join('');
      return `<g transform="translate(${x} ${y}) scale(${s})"><circle r="14" fill="#7A5A2F"/><circle r="12.5" fill="#9DCB3A"/><circle r="5" fill="#EEF0C4"/><g fill="#2A2410">${seeds}</g></g>`;
    },
    mint(x,y,s,r){
      return `<g transform="translate(${x} ${y}) rotate(${r||0}) scale(${s})"><path d="M0 0C6 -9 17 -9 22 0C17 9 6 9 0 0Z" fill="#3FA34D"/><path d="M1 0L20 0" stroke="#2C7A36" stroke-width="1.1"/></g>`;
    },
    ice(x,y,s,r){ return `<rect x="${f(x-8*s)}" y="${f(y-8*s)}" width="${f(16*s)}" height="${f(16*s)}" rx="${f(3*s)}" fill="#FFFFFF" fill-opacity=".5" stroke="#FFFFFF" stroke-opacity=".95" stroke-width="1.2" transform="rotate(${r} ${x} ${y})"/>`; }
  };
  const LIME = {rind:'#5DA832', pith:'#EAF6CF', flesh:'#B6DD63'};
  const ORANGE = {rind:'#F58A12', pith:'#FFF0D4', flesh:'#FFAE3B'};

  function frame(bg, circle, body){
    return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
      <rect width="200" height="200" fill="${bg}"/><circle cx="100" cy="98" r="78" fill="${circle}"/>
      <ellipse cx="100" cy="181" rx="56" ry="7" fill="#1E1607" opacity=".12"/>${body}</svg>`;
  }

  /* Gobelet à couvercle dôme (le gobelet réel de Snacki) */
  function cup(o){
    const id = 'c'+(++uid);
    const cupPath = 'M60 74L140 74L131 170Q130 177 123 177L77 177Q70 177 69 170Z';
    const stops = o.liquid.map((c,i)=>`<stop offset="${f(i/(o.liquid.length-1))}" stop-color="${c}"/>`).join('');
    const froth = o.froth ? `<rect x="50" y="${o.top}" width="100" height="11" fill="${o.froth}"/>
      <g fill="#FFFFFF" opacity=".75">${[[70,5,2],[82,3,1.5],[96,6,2.2],[110,4,1.6],[124,6,2],[132,3,1.3]].map(([x,dy,r])=>`<circle cx="${x}" cy="${o.top+dy}" r="${r}"/>`).join('')}</g>` : '';
    const pulp = o.pulp ? `<g fill="${o.pulp}" opacity=".55">${[[80,120],[95,150],[112,132],[122,160],[86,166],[104,108],[118,104]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="2.2" ry="1.2"/>`).join('')}</g>` : '';
    return `
      <defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1">${stops}</linearGradient>
        <clipPath id="${id}k"><path d="${cupPath}"/></clipPath></defs>
      ${o.behind || ''}
      <path d="${cupPath}" fill="#FFFFFF" fill-opacity=".35"/>
      <line x1="113" y1="160" x2="124" y2="22" stroke="${o.straw || '#FFFFFF'}" stroke-width="7" stroke-linecap="round"/>
      <line x1="113" y1="160" x2="124" y2="22" stroke="#FFFFFF" stroke-width="7" stroke-dasharray="5 6" opacity=".85"/>
      <g clip-path="url(#${id}k)"><rect x="50" y="${o.top}" width="100" height="120" fill="url(#${id}g)"/>${froth}${pulp}${o.inside || ''}</g>
      <path d="M67 82L73 82L80 170L75 170Z" fill="#FFFFFF" opacity=".45"/>
      <path d="${cupPath}" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-opacity=".95"/>
      <rect x="75" y="120" width="50" height="21" rx="6" fill="#FFC400"/>
      <text x="100" y="135.5" text-anchor="middle" font-family="'Baloo Bhaijaan 2','Tajawal',sans-serif" font-weight="800" font-size="12.5" fill="#1E1607">Snacki</text>
      <path d="M58 71C58 38 142 38 142 71Z" fill="#FFFFFF" fill-opacity=".38" stroke="#FFFFFF" stroke-width="2.2"/>
      <path d="M72 58C76 50 86 46 94 45" stroke="#FFFFFF" stroke-width="3" fill="none" stroke-linecap="round" opacity=".9"/>
      <rect x="54" y="68" width="92" height="9" rx="4.5" fill="#FFFFFF" fill-opacity=".92" stroke="#1E1607" stroke-opacity=".08"/>
      ${o.front || ''}`;
  }

  const SCENES = {
    avocat: () => frame('#EEF5DA', '#D9EAB0', cup({top:84, liquid:['#DDEBA8','#B7D06E','#9DBE52'], froth:'#EEF4CF', straw:'#3B8C2A',
      front: G.avocado(150, 160, .95, 18) + G.avocado(48, 168, .7, -25)})),
    fraise: () => frame('#FDE8EB', '#F8CCD4', cup({top:84, liquid:['#F9CCD3','#EE9BA9','#E27C8F'], froth:'#FCE3E7', straw:'#E3303E',
      front: G.strawberry(150, 164, 1.25, 12) + G.strawberry(52, 170, 1, -18) + G.strawberry(168, 178, .8, 40)})),
    mangue: () => frame('#FFF2CF', '#FFDF97', cup({top:84, liquid:['#FFD35C','#FFB22E','#F4931B'], pulp:'#E07B0C', straw:'#F58A12',
      front: G.mango(150, 160, 1.1, -20) + G.cube(52,170,1.2,12,'#FFB52E') + G.cube(66,178,1,-10,'#FFC24D') + G.cube(40,180,.9,30,'#FFA91F')})),
    orange: () => frame('#FFEBD3', '#FFD4A1', cup({top:84, liquid:['#FFC24A','#FF9F24','#F7850E'], pulp:'#FFE08A', straw:'#F58A12',
      front: G.citrus(152, 164, 20, ORANGE) + G.orange(50, 166, 1)})),
    cocktail: () => frame('#FFE9E2', '#FFCFC2', cup({top:84, liquid:['#FFB347','#FF8A4C','#EF5B6E','#D93A55'], straw:'#3B8C2A',
      front: G.kiwi(148, 170, .95) + G.strawberry(172, 170, .95, 20) + G.citrus(50, 168, 16, ORANGE)})),
    'banane-fraise': () => frame('#FFF0E0', '#FBD7C6', cup({top:84, liquid:['#FADCC4','#F4B7AE','#EC9AA1'], froth:'#FDEADF', straw:'#E3303E',
      front: G.banana(146, 172, 1.05, -12) + G.strawberry(50, 168, 1.15, -14)})),
    mojito: () => frame('#E2F5EA', '#C4EAD3', cup({top:80, liquid:['#EAF7D2','#D3EEA9','#BFE38A'], straw:'#3FA34D',
      inside: G.ice(86,98,1,15) + G.ice(110,94,1.1,-10) + G.ice(96,154,1,30) + G.mint(72,118,.9,-30) + G.mint(104,112,.8,20) + G.mint(84,162,.9,10)
        + G.citrus(118,148,11,LIME) + G.citrus(88,134,9,LIME),
      front: G.citrus(152, 166, 18, LIME) + G.mint(38, 170, 1.2, -20) + G.mint(46, 160, 1, -60)})),

    salade: () => {
      const r = rng(11), id = 's'+(++uid);
      const piece = (x,y) => {
        const k = Math.floor(r()*6), rot = Math.round(r()*80-40);
        if (k===0 || k===5) return `<g transform="rotate(${rot} ${x} ${y})"><rect x="${x-7}" y="${y-5.5}" width="14" height="11" rx="2.6" fill="#FFF1C4"/><rect x="${x-7}" y="${y-5.5}" width="14" height="3.4" rx="1.6" fill="#D8343C"/></g>`;
        if (k===1) return `<g transform="rotate(${rot} ${x} ${y})"><rect x="${x-6.5}" y="${y-5.5}" width="13" height="11" rx="2.6" fill="#F3F0BA"/><rect x="${x-6.5}" y="${y+2.2}" width="13" height="3.3" rx="1.6" fill="#A7C44A"/></g>`;
        if (k===2) return `<circle cx="${x}" cy="${y}" r="5.6" fill="#6A2C5C"/><circle cx="${x-1.8}" cy="${y-2}" r="1.6" fill="#A8629A"/>`;
        if (k===3) return `<g transform="rotate(${rot} ${x} ${y})"><ellipse cx="${x}" cy="${y}" rx="8" ry="4.6" fill="#7B3F1B"/><ellipse cx="${x-2}" cy="${y-1.5}" rx="3.2" ry="1.2" fill="#A96A3C"/></g>`;
        return r() < .5 ? G.bananaSlice(x,y,1.05) : `<circle cx="${x}" cy="${y}" r="5.6" fill="#8FB83A"/><circle cx="${x-1.8}" cy="${y-2}" r="1.6" fill="#C2DE72"/>`;
      };
      const bowl = 'M24 94Q26 170 100 172Q174 170 176 94Z';
      const mound = 'M30 98C36 70 66 56 100 56C134 56 164 70 170 98Z';
      const pts = [];
      for (let y=58; y<=170; y+=8.5) for (let x=26; x<=174; x+=11.5) pts.push([Math.round(x + (r()-.5)*6), Math.round(y + (r()-.5)*5)]);
      const body = pts.map(([x,y]) => piece(x,y)).join('');
      return frame('#FFF4D6', '#FFE2A0', `
        <defs><clipPath id="${id}"><path d="${mound}"/><path d="${bowl}"/></clipPath></defs>
        <ellipse cx="100" cy="94" rx="76" ry="17" fill="#FFFFFF" fill-opacity=".6"/>
        <g clip-path="url(#${id})"><rect x="0" y="40" width="200" height="140" fill="#F7E8B6"/>${body}</g>
        <path d="${bowl}" fill="#FFFFFF" fill-opacity=".22"/>
        <path d="M36 110Q42 156 80 164" stroke="#FFFFFF" stroke-width="4.5" fill="none" stroke-linecap="round" opacity=".65"/>
        <path d="M24 94Q26 170 100 172Q174 170 176 94" fill="none" stroke="#FFFFFF" stroke-width="2.6"/>
        <path d="M24 94A76 17 0 0 0 176 94" fill="none" stroke="#FFFFFF" stroke-width="2.6"/>
        <path d="M62 74C64 60 82 54 96 57C110 50 130 56 138 67C144 76 134 82 120 80C106 85 84 86 72 82C64 80 61 78 62 74Z" fill="#CFE497"/>
        <path d="M74 68C82 62 92 61 99 60" stroke="#F0F7D6" stroke-width="3.2" fill="none" stroke-linecap="round"/>
        <path d="M112 62C120 62 128 65 131 69" stroke="#F0F7D6" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".8"/>
        <rect x="75" y="136" width="50" height="21" rx="6" fill="#FFC400"/>
        <text x="100" y="151.5" text-anchor="middle" font-family="'Baloo Bhaijaan 2','Tajawal',sans-serif" font-weight="800" font-size="12.5" fill="#1E1607">Snacki</text>`);
    },

    crepe: () => {
      const id = 'k'+(++uid);
      const P = (cx,cy,deg,R) => [f(cx+Math.cos(deg*Math.PI/180)*R), f(cy+Math.sin(deg*Math.PI/180)*R)];
      const wedge = (cx,cy,a1,a2,R) => {
        const [x1,y1]=P(cx,cy,a1,R), [x2,y2]=P(cx,cy,a2,R), [fx1,fy1]=P(cx,cy,a1+6,R-9), [fx2,fy2]=P(cx,cy,a2-6,R-9);
        return `<path d="M${cx} ${cy}L${x1} ${y1}A${R} ${R} 0 0 1 ${x2} ${y2}Z" fill="url(#${id})" stroke="#C98A3F" stroke-width="1.4" stroke-opacity=".7"/>
          <path d="M${fx1} ${fy1}A${R-9} ${R-9} 0 0 1 ${fx2} ${fy2}" fill="none" stroke="#C98A3F" stroke-width="1.4" opacity=".45"/>`;
      };
      const spots = [[78,116],[96,98],[118,92],[132,110],[88,136],[122,132],[104,118],[70,138],[140,128]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="5" ry="2.8" fill="#B8732F" opacity=".3"/>`).join('');
      const zig = 'M66 120L78 100L88 124L100 102L110 128L122 106L132 130';
      return frame('#F8EBDC', '#EFD3B2', `
        <defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FAE0A8"/><stop offset="1" stop-color="#E3A95C"/></linearGradient></defs>
        <ellipse cx="100" cy="152" rx="88" ry="28" fill="#FFFFFF"/><ellipse cx="100" cy="150" rx="68" ry="19" fill="#F4ECDF"/>
        <g opacity=".85" transform="rotate(-8 100 120)">${wedge(50,164,282,348,112)}</g>
        ${wedge(46,162,280,350,114)}
        ${spots}
        <path d="${zig}" stroke="#4A2410" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="${zig}" stroke="#8A5230" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round" transform="translate(-.8 -1.6)"/>
        ${G.bananaSlice(78,128,1.45)}${G.bananaSlice(98,114,1.45)}${G.bananaSlice(118,122,1.45)}${G.bananaSlice(88,146,1.3)}${G.bananaSlice(108,142,1.3)}
        <g fill="#FFFFFF" opacity=".95">${[[74,106],[92,92],[110,88],[128,98],[96,132],[120,110],[82,134],[136,120],[104,150]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.2"/>`).join('')}</g>
        ${G.mint(150,64,1.1,-40)}${G.mint(156,72,.9,10)}`);
    }
  };
  return id => (SCENES[id] ? SCENES[id]() : '');
})();

const BY_ID = Object.fromEntries(PRODUCTS.map(p => [p.id, p]));

const T = {
  fr:{
    introTitle:'Jus frais et délices, prêts en quelques minutes',
    introText:'À emporter ou livrés à Nouadhibou et Cansado.',
    s1:'1. Choisissez', s2:'2. Vos infos', s3:'3. Envoi WhatsApp',
    all:'Tout', delices:'Délices', jus:'Jus naturels',
    top:'N°1 des ventes', pop:'Populaire',
    add:'Ajouter', less:'Retirer un', more:'Ajouter un',
    seeCart:'Voir mon panier',
    waLabel:'WhatsApp', callLabel:'Appel', cash:'Espèces',
    cartTitle:'Mon panier', infoTitle:'Vos informations', doneTitle:'Commande prête',
    emptyCart:'Votre panier est vide.',
    subtotal:'Total articles', items:n => n + (n>1?' articles':' article'),
    next:'Continuer', validate:'Valider la commande',
    name:'Prénom', namePh:'Ex. Aicha', nameErr:'Indiquez votre prénom (2 lettres minimum).',
    phone:'Téléphone', phoneErr:'Numéro à 8 chiffres, commençant par 2, 3 ou 4.',
    mode:'Comment récupérer ?', pickup:'À emporter', pickupSub:'au snack', delivery:'Livraison', deliverySub:'à domicile',
    zone:'Quartier', landmark:'Adresse ou repère', landmarkPh:'Ex. près de la mosquée, maison bleue', landmarkErr:'Indiquez un repère pour le livreur.',
    feeNote:'Les frais de livraison vous sont confirmés sur WhatsApp selon le quartier.',
    payment:'Paiement',
    note:'Remarque (facultatif)', notePh:'Ex. moins sucré, sans lait…',
    orderNo:'Votre numéro de commande',
    sendWa:'Envoyer sur WhatsApp', copy:'Copier le message', copied:'Message copié',
    copyFail:'Copie impossible : sélectionnez le texte du message.',
    waHelp:'Si WhatsApp ne s’ouvre pas, envoyez ce message au 37 93 94 09.',
    after:'Le snack vous confirme la commande et le délai sur WhatsApp.',
    newOrder:'Nouvelle commande',
    added:n => n + ' ajouté au panier',
    back:'Retour', close:'Fermer',
    msg:{
      head:'Nouvelle commande Snacki', no:'N°', name:'Nom', phone:'Tél', mode:'Mode',
      pickup:'À emporter', delivery:'Livraison', address:'Repère', pay:'Paiement',
      total:'Total', mobile:'à transférer', note:'Remarque', fee:'+ livraison à confirmer'
    }
  },
  ar:{
    introTitle:'عصائر طازجة وحلويات، جاهزة في دقائق',
    introText:'للأخذ أو التوصيل في انواذيبو وكانصادو.',
    s1:'١. اختر', s2:'٢. معلوماتك', s3:'٣. أرسل عبر واتساب',
    all:'الكل', delices:'حلويات', jus:'عصائر طبيعية',
    top:'الأكثر طلبًا', pop:'مطلوب',
    add:'أضف', less:'أنقص واحدًا', more:'زد واحدًا',
    seeCart:'عرض السلة',
    waLabel:'واتساب', callLabel:'اتصال', cash:'نقدًا',
    cartTitle:'سلتي', infoTitle:'معلوماتك', doneTitle:'الطلب جاهز',
    emptyCart:'سلتك فارغة.',
    subtotal:'مجموع المنتجات', items:n => n + ' ' + (n===1?'منتج':'منتجات'),
    next:'متابعة', validate:'تأكيد الطلب',
    name:'الاسم', namePh:'مثال: عائشة', nameErr:'أدخل اسمك (حرفان على الأقل).',
    phone:'الهاتف', phoneErr:'رقم من 8 أرقام يبدأ بـ 2 أو 3 أو 4.',
    mode:'كيف تستلم طلبك؟', pickup:'للأخذ', pickupSub:'من المحل', delivery:'توصيل', deliverySub:'إلى المنزل',
    zone:'الحي', landmark:'العنوان أو علامة مميزة', landmarkPh:'مثال: قرب المسجد، المنزل الأزرق', landmarkErr:'أدخل علامة مميزة لعامل التوصيل.',
    feeNote:'سنؤكد لك سعر التوصيل عبر واتساب حسب الحي.',
    payment:'طريقة الدفع',
    note:'ملاحظة (اختياري)', notePh:'مثال: سكر أقل، بدون حليب…',
    orderNo:'رقم طلبك',
    sendWa:'أرسل عبر واتساب', copy:'انسخ الرسالة', copied:'تم نسخ الرسالة',
    copyFail:'تعذّر النسخ: حدّد نص الرسالة يدويًا.',
    waHelp:'إذا لم يُفتح واتساب، أرسل هذه الرسالة إلى 37939409.',
    after:'سيؤكد لك المحل الطلب ووقت التجهيز عبر واتساب.',
    newOrder:'طلب جديد',
    added:n => 'أُضيف ' + n + ' إلى السلة',
    back:'رجوع', close:'إغلاق',
    msg:{
      head:'طلب جديد من Snacki', no:'رقم', name:'الاسم', phone:'الهاتف', mode:'الاستلام',
      pickup:'للأخذ', delivery:'توصيل', address:'العنوان', pay:'الدفع',
      total:'المجموع', mobile:'للتحويل', note:'ملاحظة', fee:'+ التوصيل يُؤكَّد لاحقًا'
    }
  }
};

/* ---------- State ---------- */
const store = {
  get(k, d){ try{ const v = localStorage.getItem('snacki_'+k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem('snacki_'+k, JSON.stringify(v)); }catch(e){} }
};
const state = {
  lang: store.get('lang', 'fr'),
  cat: 'all',
  cart: sanitizeCart(store.get('cart', {})),
  step: null,              // null | 'cart' | 'info' | 'done'
  form: Object.assign({name:'', phone:'', mode:'pickup', zone:'ndb', landmark:'', pay:'cash', note:''}, store.get('client', {})),
  touched: {},
  order: null
};
function sanitizeCart(c){
  const out = {};
  if (c && typeof c === 'object') for (const [k,v] of Object.entries(c)) {
    const q = Math.floor(Number(v));
    if (BY_ID[k] && q > 0 && q < 100) out[k] = q;
  }
  return out;
}

/* ---------- Helpers ---------- */
const $ = id => document.getElementById(id);
const t = k => T[state.lang][k];
function h(tag, attrs, ...kids){
  const el = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(kid));
  return el;
}
function svg(path, extra){
  const s = document.createElementNS('http://www.w3.org/2000/svg','svg');
  s.setAttribute('viewBox','0 0 24 24'); s.setAttribute('fill','none'); s.setAttribute('stroke','currentColor');
  s.setAttribute('stroke-width', extra || '2.6'); s.setAttribute('stroke-linecap','round'); s.setAttribute('stroke-linejoin','round');
  s.setAttribute('aria-hidden','true');
  s.innerHTML = path; return s;
}
const ICON = {
  plus:'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  leaf:'<path d="M5 19c0-8 5-13 14-14-1 9-6 14-14 14z"/><path d="M5 19l7-7"/>',
  wa:'<path d="M20.5 11.6a8.4 8.4 0 0 1-12.4 7.4L3.5 20.5l1.6-4.4A8.4 8.4 0 1 1 20.5 11.6z"/><path d="M9 8.6c0 3.2 2.9 6.3 6.3 6.4l1.1-1.4-1.9-1-.9.8c-1-.4-2.4-1.8-2.9-2.9l.8-.9-.9-1.9L9 8.6z" stroke-width="1.6"/>'
};
const fmtPlain = n => n.toLocaleString('fr-FR').replace(/[\u202f\u00a0]/g, ' ');
const fmt = n => '\u2066' + fmtPlain(n).replace(/ /g, '\u2009') + '\u2069';
const unit = () => CONFIG.unit[state.lang];
const pname = p => p[state.lang];
const cartCount = () => Object.values(state.cart).reduce((a,b)=>a+b,0);
const cartTotal = () => Object.entries(state.cart).reduce((s,[id,q]) => s + BY_ID[id].price*q, 0);
function setQty(id, q){
  q = Math.max(0, Math.min(99, q));
  if (q === 0) delete state.cart[id]; else state.cart[id] = q;
  store.set('cart', state.cart);
}
let toastTimer;
function toast(msg){
  const el = $('toast'); el.textContent = msg; el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(()=>{ el.hidden = true; }, 1800);
}

/* ---------- Menu ---------- */
// Visuel produit : photo si p.photo est renseigné, sinon illustration SVG (chaînes constantes du code, jamais de saisie client)
function artEl(cls, p, label){
  if (p.photo) return h('img', {class:cls, src:p.photo, alt:label, loading:'lazy'});
  const el = h('div', {class:cls, role: label ? 'img' : null, 'aria-label': label || null});
  el.innerHTML = ART(p.id);
  return el;
}
function priceEl(v){ return h('span', {class:'price'}, fmt(v), h('small', null, unit())); }
function qtyControl(p, compact){
  const q = state.cart[p.id] || 0;
  if (!q && !compact) {
    const b = h('button', {type:'button', class:'add', 'aria-label': t('add') + ' — ' + pname(p), onclick:()=>{ setQty(p.id, 1); toast(t('added')(pname(p))); renderAll(); }}, svg(ICON.plus));
    return b;
  }
  return h('div', {class:'stepper', role:'group', 'aria-label': pname(p)},
    h('button', {type:'button', 'aria-label': t('less') + ' — ' + pname(p), onclick:()=>{ setQty(p.id, q-1); renderAll(); }}, svg(ICON.minus)),
    h('output', {'aria-live':'polite'}, String(q)),
    h('button', {type:'button', 'aria-label': t('more') + ' — ' + pname(p), onclick:()=>{ setQty(p.id, q+1); renderAll(); }}, svg(ICON.plus))
  );
}
function card(p){
  const other = state.lang === 'fr' ? 'ar' : 'fr';
  return h('article', {class:'card'},
    artEl('ph', p, pname(p)),
    p.badge ? h('span', {class:'badge' + (p.badge==='pop'?' pop':'')}, t(p.badge)) : null,
    h('div', {class:'cbody'},
      h('h3', {class:'name'}, pname(p)),
      h('p', {class:'alt', lang:other, dir: other==='ar'?'rtl':'ltr'}, p[other]),
      h('p', {class:'desc'}, state.lang==='fr' ? p.dfr : p.dar),
      h('div', {class:'row'}, priceEl(p.price), qtyControl(p))
    )
  );
}
function renderTabs(){
  const tabs = $('tabs'); tabs.replaceChildren();
  for (const c of ['all','delices','jus']) {
    tabs.append(h('button', {type:'button', role:'tab', id:'tab-'+c, class:'tab', 'aria-selected': String(state.cat===c),
      onclick:()=>{ state.cat = c; renderAll(); }}, t(c)));
  }
}
function renderMenu(){
  const menu = $('menu'); menu.replaceChildren();
  for (const c of ['delices','jus']) {
    if (state.cat !== 'all' && state.cat !== c) continue;
    const items = PRODUCTS.filter(p => p.cat === c);
    menu.append(h('section', {class:'section', 'aria-labelledby':'sec-'+c},
      h('h2', {class:'brush', id:'sec-'+c}, h('span', null, svg(ICON.leaf,'2')), h('span', null, t(c))),
      h('div', {class:'grid'}, items.map(card))
    ));
  }
}
function renderBar(){
  const n = cartCount();
  $('bar').hidden = n === 0 || state.step !== null;
  $('bar-count').textContent = n;
  $('bar-total').textContent = fmt(cartTotal()) + ' ' + unit();
}
function renderStatic(){
  const L = state.lang;
  document.documentElement.lang = L;
  document.documentElement.dir = L === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-t]').forEach(el => { el.textContent = t(el.dataset.t); });
  $('lang-fr').setAttribute('aria-pressed', String(L==='fr'));
  $('lang-ar').setAttribute('aria-pressed', String(L==='ar'));
  $('sheet-back').setAttribute('aria-label', t('back'));
  $('sheet-close').setAttribute('aria-label', t('close'));
}

/* ---------- Checkout sheet ---------- */
function validate(){
  const f = state.form, e = {};
  if (f.name.trim().length < 2) e.name = t('nameErr');
  if (!/^[234]\d{7}$/.test(f.phone.replace(/\s/g,''))) e.phone = t('phoneErr');
  if (f.mode === 'delivery' && f.landmark.trim().length < 3) e.landmark = t('landmarkErr');
  return e;
}
function optButton(label, sub, checked, onclick, id){
  return h('button', {type:'button', role:'radio', id, class:'opt', 'aria-checked': String(checked), onclick},
    h('span', null, label, sub ? h('small', null, sub) : null));
}
function renderSheet(){
  const open = state.step !== null;
  $('scrim').hidden = !open;
  document.body.style.overflow = open ? 'hidden' : '';
  if (!open) return;
  const s = state.step;
  const titles = {cart:'cartTitle', info:'infoTitle', done:'doneTitle'};
  $('sheet-title').textContent = t(titles[s]);
  $('sheet-back').hidden = s !== 'info';
  const idx = {cart:1, info:2, done:3}[s];
  ['p1','p2','p3'].forEach((p,i) => $(p).className = i < idx ? 'on' : '');
  const body = $('sbody'), foot = $('sfoot');
  body.replaceChildren(); foot.replaceChildren();

  if (s === 'cart') {
    const ids = Object.keys(state.cart);
    if (!ids.length) { body.append(h('p', {class:'muted'}, t('emptyCart'))); return; }
    for (const id of ids) {
      const p = BY_ID[id], q = state.cart[id];
      body.append(h('div', {class:'line'},
        artEl('thumb', p, ''),
        h('div', null, h('div', {class:'n'}, pname(p)), h('div', {class:'s'}, q + ' × ' + fmt(p.price) + ' = ' + fmt(q*p.price) + ' ' + unit())),
        qtyControl(p, true)
      ));
    }
    foot.append(
      h('div', {class:'sum big'}, h('span', null, t('subtotal')), h('span', null, fmt(cartTotal()) + ' ' + unit())),
      h('button', {type:'button', class:'primary', id:'to-info', onclick:()=>{ state.step='info'; renderAll(); }}, t('next'))
    );
  }

  if (s === 'info') {
    const f = state.form, errs = validate(), show = k => state.touched[k] && errs[k];
    const upd = (k, rerender) => ev => { f[k] = ev.target.value; store.set('client', {name:f.name, phone:f.phone, zone:f.zone, landmark:f.landmark}); if (rerender) renderAll(); else refreshInfoState(); };
    const blur = k => () => { state.touched[k] = true; refreshInfoState(); };

    body.append(
      h('div', {class:'field'},
        h('label', {for:'f-name'}, t('name')),
        h('input', {id:'f-name', autocomplete:'given-name', placeholder:t('namePh'), value:f.name, maxlength:'40', 'aria-invalid': String(!!show('name')), oninput:upd('name'), onblur:blur('name')}),
        h('div', {class:'err', id:'e-name'}, show('name') || '')
      ),
      h('div', {class:'field'},
        h('label', {for:'f-phone'}, t('phone')),
        h('div', {class:'phone' + (show('phone')?' bad':''), id:'w-phone'}, h('span', null, '+222'),
          h('input', {id:'f-phone', type:'tel', inputmode:'numeric', autocomplete:'tel-national', placeholder:'37 93 94 09', value:f.phone, maxlength:'11', oninput:upd('phone'), onblur:blur('phone')})),
        h('div', {class:'err', id:'e-phone'}, show('phone') || '')
      ),
      h('div', {class:'field'},
        h('div', {class:'lab', id:'l-mode'}, t('mode')),
        h('div', {class:'seg', role:'radiogroup', 'aria-labelledby':'l-mode'},
          optButton(t('pickup'), t('pickupSub'), f.mode==='pickup', ()=>{ f.mode='pickup'; renderAll(); }, 'm-pickup'),
          optButton(t('delivery'), t('deliverySub'), f.mode==='delivery', ()=>{ f.mode='delivery'; renderAll(); }, 'm-delivery'))
      )
    );
    if (f.mode === 'delivery') {
      body.append(
        h('div', {class:'field'},
          h('label', {for:'f-zone'}, t('zone')),
          h('select', {id:'f-zone', onchange:upd('zone')}, CONFIG.zones.map(z => h('option', {value:z.id, selected: f.zone===z.id}, z[state.lang])))
        ),
        h('div', {class:'field'},
          h('label', {for:'f-landmark'}, t('landmark')),
          h('input', {id:'f-landmark', placeholder:t('landmarkPh'), value:f.landmark, maxlength:'120', 'aria-invalid': String(!!show('landmark')), oninput:upd('landmark'), onblur:blur('landmark')}),
          h('div', {class:'err', id:'e-landmark'}, show('landmark') || '')
        ),
        h('p', {class:'note-box fee'}, t('feeNote'))
      );
    }
    body.append(
      h('div', {class:'field'},
        h('div', {class:'lab', id:'l-pay'}, t('payment')),
        h('div', {class:'chips', role:'radiogroup', 'aria-labelledby':'l-pay'},
          CONFIG.payments.map(p => optButton(p[state.lang], null, f.pay===p.id, ()=>{ f.pay=p.id; renderAll(); }, 'pay-'+p.id))),
      ),
      h('div', {class:'field'},
        h('label', {for:'f-note'}, t('note')),
        h('textarea', {id:'f-note', rows:'2', maxlength:'200', placeholder:t('notePh'), oninput:upd('note')}, f.note)
      )
    );
    foot.append(
      h('div', {class:'sum'}, h('span', {class:'muted'}, t('items')(cartCount())), h('strong', {class:'sum-v'}, fmt(cartTotal()) + ' ' + unit())),
      h('button', {type:'button', class:'primary', id:'validate', onclick:submitInfo}, t('validate'))
    );
  }

  if (s === 'done') {
    const o = state.order;
    body.append(
      h('div', {class:'done-num'}, h('div', {class:'k'}, t('orderNo')), h('div', {class:'v'}, o.no)),
      h('div', {class:'msg', id:'wa-msg', dir: state.lang==='ar'?'rtl':'ltr'}, o.text),
      h('p', {class:'muted gap10'}, t('waHelp')),
      h('p', {class:'muted gap6'}, t('after'))
    );
    foot.append(
      h('a', {class:'primary wa', id:'send-wa', href:'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(o.text), target:'_blank', rel:'noopener'}, svg(ICON.wa,'1.8'), t('sendWa')),
      h('button', {type:'button', class:'ghost', id:'copy', onclick:copyMsg}, t('copy')),
      h('button', {type:'button', class:'ghost', id:'new-order', onclick:newOrder}, t('newOrder'))
    );
  }
}
function refreshInfoState(){
  const errs = validate();
  for (const k of ['name','phone','landmark']) {
    const e = $('e-'+k); if (!e) continue;
    const msg = state.touched[k] && errs[k];
    e.textContent = msg || '';
    const inp = $('f-'+k); if (inp && k !== 'phone') inp.setAttribute('aria-invalid', String(!!msg));
    if (k === 'phone') $('w-phone').className = 'phone' + (msg ? ' bad' : '');
  }
}
function submitInfo(){
  const errs = validate();
  if (Object.keys(errs).length) {
    state.touched = {name:true, phone:true, landmark:true};
    refreshInfoState();
    const first = ['name','phone','landmark'].find(k => errs[k]);
    const el = $('f-'+first); if (el) el.focus();
    return;
  }
  state.order = buildOrder();
  state.step = 'done';
  renderAll();
}
function orderNumber(){
  const d = new Date();
  const mmdd = String(d.getMonth()+1).padStart(2,'0') + String(d.getDate()).padStart(2,'0');
  const rnd = (crypto.getRandomValues(new Uint16Array(1))[0] % 900) + 100;
  return 'SNK-' + mmdd + '-' + rnd;
}
function buildOrder(){
  const f = state.form, M = t('msg'), no = orderNumber();
  const clean = s => s.replace(/[\r\n]+/g, ' ').trim();
  const pay = CONFIG.payments.find(p => p.id === f.pay);
  const zone = CONFIG.zones.find(z => z.id === f.zone);
  const phone = f.phone.replace(/\s/g,'');
  // En arabe, les nombres à plusieurs blocs (1 200, +222 37 93…) seraient inversés :
  // on les encadre de marques LRM (U+200E), reconnues par tous les téléphones.
  const L = state.lang === 'ar' ? '\u200E' : '';
  const num = v => L + v + L;
  const lines = [
    '*' + M.head + '*',
    M.no + ' : ' + num(no),
    '',
    ...Object.entries(state.cart).map(([id,q]) => q + ' × ' + pname(BY_ID[id]) + ' — ' + num(fmtPlain(q*BY_ID[id].price))),
    '',
    '*' + M.total + ' : ' + num(fmtPlain(cartTotal())) + ' ' + unit() + '*' + (f.mode==='delivery' ? ' ' + M.fee : ''),
    M.pay + ' : ' + pay[state.lang] + '',
    '',
    M.name + ' : ' + clean(f.name),
    M.phone + ' : ' + num('+222 ' + phone.replace(/(\d{2})(?=\d)/g,'$1 ').trim()),
    M.mode + ' : ' + (f.mode==='delivery' ? M.delivery + ' — ' + zone[state.lang] : M.pickup),
    f.mode==='delivery' ? M.address + ' : ' + clean(f.landmark) : null,
    clean(f.note) ? M.note + ' : ' + clean(f.note) : null
  ].filter(l => l !== null);
  return {no, text: lines.join('\n')};
}
function copyMsg(){
  const text = state.order.text;
  const fallback = () => {
    const el = $('wa-msg'); const r = document.createRange(); r.selectNodeContents(el);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
    toast(t('copyFail'));
  };
  try {
    navigator.clipboard.writeText(text).then(()=>toast(t('copied')), fallback);
  } catch(e){ fallback(); }
}
function newOrder(){
  state.cart = {}; store.set('cart', {});
  state.form.note = ''; state.order = null; state.touched = {};
  state.step = null; renderAll();
  window.scrollTo({top:0});
}

/* ---------- Wiring ---------- */
function renderAll(){
  renderStatic(); renderTabs(); renderMenu(); renderBar(); renderSheet();
}
document.querySelectorAll('[data-lang]').forEach(b => b.addEventListener('click', () => {
  state.lang = b.dataset.lang; store.set('lang', state.lang);
  if (state.step === 'done') state.order.text = buildOrder().text.replace(/SNK-\d{4}-\d{3}/, state.order.no);
  renderAll();
}));
$('open-cart').addEventListener('click', () => { state.step = 'cart'; renderAll(); });
$('sheet-close').addEventListener('click', () => { state.step = null; renderAll(); });
$('sheet-back').addEventListener('click', () => { state.step = 'cart'; renderAll(); });
$('scrim').addEventListener('click', e => { if (e.target === $('scrim') && state.step !== 'done') { state.step = null; renderAll(); } });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && state.step && state.step !== 'done') { state.step = null; renderAll(); } });

renderAll();
})();

/* PWA : service worker (cache hors ligne), uniquement en HTTPS ou sur localhost */
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
}
