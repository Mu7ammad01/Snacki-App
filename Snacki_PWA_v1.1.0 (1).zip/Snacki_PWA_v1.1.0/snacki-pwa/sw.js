/* Snacki — service worker v1.1.0
   Changer CACHE à chaque mise en ligne pour que les téléphones récupèrent la nouvelle version. */
const CACHE = 'snacki-v1.1.0';
const ASSETS = [
  "./",
  "index.html",
  "styles.css",
  "app.js",
  "manifest.webmanifest",
  "img/logo.jpg",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/maskable-512.png",
  "icons/apple-touch-icon.png",
  "icons/favicon-32.png",
  "fonts/tajawal-arabic-400.woff2",
  "fonts/tajawal-latin-400.woff2",
  "fonts/tajawal-arabic-500.woff2",
  "fonts/tajawal-latin-500.woff2",
  "fonts/tajawal-arabic-700.woff2",
  "fonts/tajawal-latin-700.woff2",
  "fonts/baloo-bhaijaan-2-arabic-500.woff2",
  "fonts/baloo-bhaijaan-2-latin-500.woff2",
  "fonts/baloo-bhaijaan-2-arabic-700.woff2",
  "fonts/baloo-bhaijaan-2-latin-700.woff2",
  "fonts/baloo-bhaijaan-2-arabic-800.woff2",
  "fonts/baloo-bhaijaan-2-latin-800.woff2"
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return; // WhatsApp, etc. : on ne touche pas
  if (req.mode === 'navigate') {
    // Page : réseau d'abord (pour avoir les nouveaux prix), cache si hors ligne
    event.respondWith(
      fetch(req).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put('index.html', copy)); return res; })
        .catch(() => caches.match('index.html'))
    );
    return;
  }
  // Fichiers (css, js, polices, icônes) : cache d'abord
  event.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
      return res;
    }))
  );
});
